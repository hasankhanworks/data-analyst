In this project we find 
1. no of man of matches
2. no of wins
3. no of lose
ETC