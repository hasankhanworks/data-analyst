In this project we make plots using python using parameter
salary , nationality , height etc. 