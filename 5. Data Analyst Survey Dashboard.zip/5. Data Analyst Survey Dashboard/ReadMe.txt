
In this project , we find
1.Top 3 Average salary by job in data science.
2.Top 3 programing language in data science.
3. Difficulty level to break into data science .