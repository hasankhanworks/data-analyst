In this project , we find
1.Top 10 customer .
2.Top 3 Region by sale.