Objective : SAM Hospitals  wants us to help them create a dashboard to provide data-driven insights into  hospital operations, financial performance, and patient care to support informed decision-making. .

Steps -
1. Import data .
2. Data Cleaning . 
3. Change data type of Admit_Date and Discharge_Date  Column , Whole Number  to Date . 
4. Change canvas background .
5. Change Format of Billing Amount Dollar to Rupees.


Results -
1. Top 3 Diagnosis are Viral Infection , Flu , Malaria . 
2. Pneumonia and Fractures have fewer cases . 
3. Top Bed Occupancy is Private . 
4. Top Billing Amount is Viral Infections: ₹53M billed, ₹48M covered by insurance.



Project Learning - 
1. Create interactive dashboard to track and analyse hospital data.
2. Use of  filters and slicers .
3. Use of different types of customised visualisations  . 
