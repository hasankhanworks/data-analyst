In this project , I find
1. Total number of cars sold each year, and

2. Number of cars sold by fuel type (CNG, Petrol, Diesel) for each year.

