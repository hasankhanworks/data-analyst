Objective : A store owner wants us to help them create a dashboard to track and analyse their online sales across India .

Steps -
1. Import data .
2. Data Cleaning . F
3. Change data type of Order Date Column , Text to Date . 
4. Change canvas background .
5. Create a new column AOV by using Column Tool and change its data type , decimal to whole number .


Results -
1. Top 4 sates are Maharashtra , M. P. , U.P. , Delhi .
2. Top 3 payment mode COD , UPI , Debit Card .
3. Top profitable months are NOV , JAN , FEB , MARCH , APRIL .
4. Top Category Clothing , Electronics , Furniture .
5. Top Sub Category are Printers , Bookcases , Saree , Accessories , Tables .


Project Learning - 
1. Craete interactive dashboard to track and analyse online sales data.
2. Use of drill down , filters and slicers .
3. Use of different types of customised visualisations . 


