# Python_Diwali_Sales_Analysis
In this project we analyse diwali sales data using python and find who has more purchacing power and from where they belong .
